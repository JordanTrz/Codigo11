import { useEffect, useState } from "react";
import axios from 'axios';

const CarRegister = () =>{

  const initialStateValues = {
    marca: "",
    modelo: "",
    categoria: "",
    añomfabricacion: "",
    añomodelo: "",
    kilometraje: "",
    transmision: "",
    combustible: "",
    cilindrada: "",
    numeropuertas: "",
    color: "",
    preciodolares: "",
    region: "",
    photos: "",
  }
  const url = 'http://localhost:5000/marcas/';
  const [newDataCar, setNewDataCar] = useState([]);
  const [newDataModel, setnewDataModel] = useState([]);
  const [newDataForm, setnewDataForm] = useState([initialStateValues]);

  const getDataCar = async () => {
      const dataCar = await axios.get(url)
      return dataCar.data;
  }

  useEffect(() => {
    const getAllDataCar = async () => {
      const allDataCar = await getDataCar();
      if(allDataCar) setNewDataCar(allDataCar);
    }
    getAllDataCar();
  }, []);

  useEffect(() =>{

  }, [])

  const handleChange = (e) =>{
    console.log(e.target.value);
    setnewDataForm({...initialStateValues,marca:e.target.value})
    console.log(newDataForm.marca);
  }

  // useEffect(() => {
  //   // setnewDataForm(marcas.filter((marca) => marca.id == form.brand));
  //   console.log
  // }, []);

  return(
    <div className="carRegister_wrapper">
      <div className="carRegister__Publish">
        <h2>Datos del Vehículo</h2>
        <form>
          <div className="carRegister__Inputs">
            <select onChange={handleChange} name="marcas" id="marcas">
              <option>Marcas</option>
                {newDataCar.map((marcaCarros) => {
                  return(
                  <option value={marcaCarros.id} key={marcaCarros.id}>{marcaCarros.marca}</option>
                  )
                })}
            </select>
            <select>
              <option>Modelos</option>
              {

              }
            </select>
            <select>
              <option>Categorías</option>
            </select>
            <select>
              <option>Año de fabricación</option>
            </select>
            <select>
              <option>Año de modelo</option>
            </select>
            <select>
              <option>Transmisiones</option>
            </select>
            <select>
              <option>Combustibles</option>
            </select>
            <select>
              <option>Cilindrada</option>
            </select>
            <select>
              <option>Número de puertas</option>
            </select>
            <input placeholder="Color"/>
            <input placeholder="Precio en Dólares"/>
            <select>
              <option>Regiones</option>
            </select>
            <input type="text" placeholder="Link de photo"/>
          </div>
          <div>

          </div>
          <div>
            <button>PUBLICAR</button>
          </div>
        </form>
      </div>
    </div>
  )
}

export default CarRegister;